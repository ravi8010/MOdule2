package com.cap.pages;

public class SuccessPage {

}
