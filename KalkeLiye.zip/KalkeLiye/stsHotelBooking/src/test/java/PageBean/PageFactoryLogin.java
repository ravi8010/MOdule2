package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryLogin {
	
	
	WebDriver driver;
	
	//Identifying elements using name, how class, className
	@FindBy(name="userName")
	@CacheLookup
	WebElement pfuname;
	
	
	@FindBy(how=How.NAME, using="userPwd")
	@CacheLookup
	WebElement pfpwd;


	@FindBy(className="btn")
	@CacheLookup
	WebElement pflogin;
	
	@FindBy(xpath=".//*[@id='mainCnt']/div[1]/div[1]/form/table/tbody/tr[4]/td[2]/input[1]")
	@CacheLookup
	WebElement male;
	@FindBy(xpath=".//*[@id='mainCnt']/div[1]/div[1]/form/table/tbody/tr[4]/td[2]/input[2]")
	@CacheLookup
	WebElement female;
	@FindBy(xpath=".//*[@id='mainCnt']/div[1]/div[1]/form/table/tbody/tr[4]/td[2]/input[3]")
	@CacheLookup
	WebElement other;
	
	@FindBy(id="age")
	@CacheLookup
	WebElement cage;
	@FindBy(id="terms")
	@CacheLookup
	WebElement cterms;
	
	
	public WebElement getCage() {
		return cage;
	}


	public void setCage() {
		cage.click();
	}


	public WebElement getCterms() {
		return cterms;
	}


	public void setCterms() {
		cterms.click();;
	}


	public WebElement getMale() {
		return male;
	}


	public void setMale() {
		male.click();
	}


	public WebElement getFemale() {
		return female;
	}


	public void setFemale() {
		female.click();
	}


	public WebElement getOther() {
		return other;
	}


	public void setOther() {
		other.click();
	}


	public PageFactoryLogin(WebDriver driver) {
		
		this.driver = driver;
		
		PageFactory.initElements(driver,this);
	}
	
	
	public void setPfuname(String suname) {
		pfuname.sendKeys(suname);
	}
	public void setPfpwd(String supwd) {
		pfpwd.sendKeys(supwd);
	}
	public void setPflogin() {

		pflogin.click();
	}
	
	public WebElement getPfuname() {
		return pfuname;
	}
	public WebElement getPfpwd() {
		return pfpwd;
	}
	public WebElement getPflogin() {
		return pflogin;
	}
		
		


}
